# voice-controlled
Developed a Python-based application that allows users to customize voice commands for system  operations such as shutdown, sleep, etc. 
